package android.example.com.popularmovies.Model;

/**
 * Created by arjunachatz on 2017-02-28.
 * Copyright © 2016 Matter and Form. All rights reserved.
 */

public class Review {
    public String mAuthor, mContent;
}
