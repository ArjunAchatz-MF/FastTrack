package android.example.com.popularmovies.Model;

/**
 * Created by arjunachatz on 2017-02-28.
 * Copyright © 2016 Matter and Form. All rights reserved.
 */

public class Video {

    public String mId;
    public String mKey;
    public String mName;
    public String mSite;
    public int mSize;
    public String mType;

    public Video(){

    }

}
